# HTML







HTML is a markup language that can be used to define the structure of a web page. HTML elements include







* headings



* paragraphs



* lists



* links



* and more!







The most recent major version of HTML is HTML5.

